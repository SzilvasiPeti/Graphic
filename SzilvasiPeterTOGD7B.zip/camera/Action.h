#pragma 

int mforward;
int mbackward;
int sleft;
int sright;

int mforw()
{
	return mforward;
}
int mbackw()
{
	return mbackward;
}
int mleft()
{
	return sleft;
}
int mright()
{
	return sright;
}
