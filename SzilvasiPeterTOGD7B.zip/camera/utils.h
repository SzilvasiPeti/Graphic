#ifndef UTILS_H
#define UTILS_H

/**
 * Calculates radian from degree.
 */
double degree_to_radian(double degree);

#endif /* UTILS_H */

