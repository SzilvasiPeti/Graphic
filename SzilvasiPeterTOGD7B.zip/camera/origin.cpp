#include "camera.h"
#include "model.h"
#include "draw.h"
#include "utils.h"
#include "Action.h"

#include <GL/glut.h>
#include <SOIL/SOIL.h>

#include <stdio.h>

#define _USE_MATH_DEFINES 
#include <math.h>

#define VIEWPORT_RATIO (4.0 / 3.0)
#define VIEWPORT_ASPECT 50.0

#define CAMERA_SPEED 2.0

int mouse_x, mouse_y;

Model model;
Model model1;
Model model2;
Model model3;
Model model4;

Camera camera;

int time;

GLfloat xRotated, yRotated, zRotated;
GLdouble radius = 1;

typedef GLubyte Pixel[3]; /*represents red green blue*/

GLuint textures[10];

double distance;

bool drawMenu = FALSE;
bool openDoor = FALSE;

GLfloat light = 0;
GLfloat c = 0;
GLfloat x = 0;
float lr = 1;
float lg = 1;
float lb = 1;

float forgoszog = 0;
bool ajto = false;
bool door_is_open = true;

GLuint LoadTextureFromFile(const char *filename)
{
	return SOIL_load_OGL_texture(
		filename,
		SOIL_LOAD_AUTO,
		SOIL_CREATE_NEW_ID,
		SOIL_FLAG_MIPMAPS | SOIL_FLAG_NTSC_SAFE_RGB
	);
}

void set_lightings()
{
	GLfloat light_position[] = { 6, 6+light, 11, 0.0 };
	GLfloat light_ambient[] = { 0, 0, 0, 1 };
	GLfloat light_diffuse[] = { 255, 215, 0, 0 };
	GLfloat light_specular[] = { 1 + c, 1 + c, 1 + c, 1 };

	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
}

void lightning_init() {

	GLfloat light_colorA[] = { lr, lg, lb, 0 };
	GLfloat difLight[] = { 0.5,0.5,0.5,1 };

	glLightfv(GL_LIGHT0, GL_DIFFUSE, difLight);
	glLightfv(GL_LIGHT1, GL_AMBIENT, light_colorA);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_DEPTH_TEST);
}

void draw_skybox()
{
	double theta, phi1, phi2;
	double x1, y1, z1;
	double x2, y2, z2;
	double u, v1, v2;

	int n_slices, n_stacks;
	double radius;
	int i, k;

	n_slices = 12;
	n_stacks = 6;
	radius = 80;

	glPushMatrix();

	glScaled(radius, radius, radius);

	glColor3f(1, 1, 1);

	glBegin(GL_TRIANGLE_STRIP);

	for (i = 0; i < n_stacks; ++i) {
		v1 = (double)i / n_stacks;
		v2 = (double)(i + 1) / n_stacks;
		phi1 = v1 * M_PI / 2.0;
		phi2 = v2 * M_PI / 2.0;
		for (k = 0; k <= n_slices; ++k) {
			u = (double)k / n_slices;
			theta = u * 2.0 * M_PI;
			x1 = cos(theta) * cos(phi1);
			y1 = sin(theta) * cos(phi1);
			z1 = sin(phi1);
			x2 = cos(theta) * cos(phi2);
			y2 = sin(theta) * cos(phi2);
			z2 = sin(phi2);
			glTexCoord2d(u, 1.0 - v1);
			glVertex3d(x1, y1, z1);
			glTexCoord2d(u, 1.0 - v2);
			glVertex3d(x2, y2, z2);
		}
	}

	glEnd();

	glPopMatrix();
}

void Fog() {
	GLfloat fogColor[] = { 0.5f, 0.5f, 0.5f, 1 };
	//GLfloat fogColor1[] = { 0.3f, 0.3f, 1.0f, 1 };
	glFogfv(GL_FOG_COLOR, fogColor);
	//glFogfv(GL_FOG_COLOR, fogColor);
	glFogi(GL_FOG_MODE, GL_LINEAR);
	glFogf(GL_FOG_START, 0.0f);
	glFogf(GL_FOG_END, 120.0f);
}

void draw_teapots()
{
	/* Teapot 2 */
	glPushMatrix();
	glTranslatef(0.7f, 19.5f, 2.2f);
	glRotatef(90, 1, 0, 0);


	GLfloat material_diffuse_2[] = { 0, 0, 1, 2 };
	GLfloat material_specular[] = { 4, 4, 4, 4 };

	glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse_2);
	glMaterialfv(GL_FRONT, GL_SPECULAR, material_specular);

	GLfloat material_shininess[] = { 50.0 };
	glMaterialfv(GL_FRONT, GL_SHININESS, material_shininess);

	glutSolidTeapot(1.0);
	glPopMatrix();
}

void draw_origin()
{
	//ajt�1

	glBindTexture(GL_TEXTURE_2D, textures[6]);
	glDisable(GL_CULL_FACE);


	int forgas = 85;
	if (forgoszog > forgas) {
		forgoszog = forgas;
	}
	if (forgoszog<0)
	{
		forgoszog = 0;
	}
	if (ajto) {
		forgoszog += 1;
	}
	else {
		forgoszog -= 1;
	}

	glPushMatrix();

	glTranslatef(2, -5.6, 0);
	glRotatef(forgoszog, 0, 0, -1);
	glTranslatef(-2, 5.6, 0);
	glBegin(GL_QUADS);


	glTexCoord2f(0.0, 0.0);
	glVertex3d(2, -5.6, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3d(2, -5.6, 6);

	glTexCoord2f(1.0, 1.0);
	glVertex3d(-2.15, -5.6, 6);

	glTexCoord2f(1.0, 0.0);
	glVertex3d(-2.15, -5.6, 0.0);

	glEnd();
	glPopMatrix();

	//MEN�
	if (drawMenu)
	{
		camera.pose.x = 0;
		camera.pose.y = 0;
		camera.pose.z = 0;

		glBindTexture(GL_TEXTURE_2D, textures[0]);
		glPushMatrix();
		glBegin(GL_POLYGON);

		glTexCoord2f(0.0, 0.0);
		glVertex3d(camera.position.x + 2.125, camera.position.y - 1.125, camera.position.z - 1.0);

		glTexCoord2f(0.0, 1.0);
		glVertex3d(camera.position.x + 2.125, camera.position.y - 1.125, camera.position.z + 1.0);

		glTexCoord2f(1.0, 1.0);
		glVertex3d(camera.position.x + 2.125, camera.position.y + 1.125, camera.position.z + 1.0);

		glTexCoord2f(1.0, 0.0);
		glVertex3d(camera.position.x + 2.125, camera.position.y + 1.125, camera.position.z - 1.0);

		glEnd();
		glPopMatrix();
	}

	//F�
	glPushMatrix();
	glBindTexture(GL_TEXTURE_2D, textures[1]);
	glBegin(GL_POLYGON);

	glTexCoord2f(0.0, 0.0);
	glVertex3d(-100, -100, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3d(-100, 0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3d(0, 0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3d(0, -100, 0.0);

	glEnd();
	glBindTexture(GL_TEXTURE_2D, textures[1]);
	glBegin(GL_POLYGON);

	glTexCoord2f(0.0, 0.0);
	glVertex3d(0, -100, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3d(100, -100, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3d(100, 0, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3d(0, 0, 0.0);

	glEnd();
	
	glBindTexture(GL_TEXTURE_2D, textures[1]);
	glBegin(GL_POLYGON);

	glTexCoord2f(0.0, 0.0);
	glVertex3d(0, 0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3d(100, 0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3d(100, 100, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3d(0, 100, 0.0);

	glEnd();
	glBindTexture(GL_TEXTURE_2D, textures[1]);
	glBegin(GL_POLYGON);

	glTexCoord2f(0.0, 0.0);
	glVertex3d(0, 0, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3d(-100, 0, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3d(-100, 100, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3d(0, 100, 0.0);

	glEnd();
	glPopMatrix();

	glBindTexture(GL_TEXTURE_2D, textures[4]);
	draw_skybox();
	//H�Z
	glPushMatrix();
	glScalef(0.25, 0.25, 0.25);
	glRotatef(90, 1, 0, 0);
	glBindTexture(GL_TEXTURE_2D, textures[5]);
	draw_model(&model);
	glPopMatrix();

	//ASZTAL
	glPushMatrix();
	glTranslatef(0, 20, 0);
	glRotatef(90, 1, 0, 0);
	glBindTexture(GL_TEXTURE_2D, textures[9]);
	draw_model(&model4);
	glPopMatrix();

	//F�K
	glPushMatrix();
	glScalef(1.5, 1.5, 1.5);
	glTranslatef(20, 10, 0);
	glRotatef(90, 1, 0, 0);
	glBindTexture(GL_TEXTURE_2D, textures[7]);
	draw_model(&model1);
	glBindTexture(GL_TEXTURE_2D, textures[8]);
	draw_model(&model3);
	glTranslatef(10, 0, 0);
	glBindTexture(GL_TEXTURE_2D, textures[7]);
	draw_model(&model1);
	glBindTexture(GL_TEXTURE_2D, textures[8]);
	draw_model(&model3);
	glTranslatef(-5, 0, 10);
	glBindTexture(GL_TEXTURE_2D, textures[7]);
	draw_model(&model1);
	glBindTexture(GL_TEXTURE_2D, textures[8]);
	draw_model(&model3);
	glTranslatef(10, 0, 10);
	glBindTexture(GL_TEXTURE_2D, textures[7]);
	draw_model(&model1);
	glBindTexture(GL_TEXTURE_2D, textures[8]);
	draw_model(&model3);
	glTranslatef(0, 0, 10);
	glBindTexture(GL_TEXTURE_2D, textures[7]);
	draw_model(&model1);
	glBindTexture(GL_TEXTURE_2D, textures[8]);
	draw_model(&model3);
	glPopMatrix();

	//V�Z
	glPushMatrix();
	glTranslatef(-20, -10, 1.5);
	glBindTexture(GL_TEXTURE_2D, textures[2]);
	glBegin(GL_POLYGON);

	glTexCoord2f(0.0, 0.0);
	glVertex3d(-8, -8, 0.0);

	glTexCoord2f(0.0, 1.0);
	glVertex3d(-8, 8, 0.0);

	glTexCoord2f(1.0, 1.0);
	glVertex3d(8, 8, 0.0);

	glTexCoord2f(1.0, 0.0);
	glVertex3d(8, -8, 0.0);

	glEnd();
	glPopMatrix();

	//Medence
	glPushMatrix();
	glTranslatef(-17.5, -2.5, 0);
	glScalef(2.15f, 1.0f, 0.8f);
	glBindTexture(GL_TEXTURE_2D, textures[3]);
	draw_model(&model2);
	glTranslatef(-4.25, -5.25, 0);
	glRotatef(90, 0, 0, 1);
	glScalef(2.15f, 1.0f, 1.0f);
	glBindTexture(GL_TEXTURE_2D, textures[3]);
	draw_model(&model2);
	glTranslatef(-4.25, -2, 0);
	glRotatef(90, 0, 0, 1);
	glBindTexture(GL_TEXTURE_2D, textures[3]);
	draw_model(&model2);
	glTranslatef(-4.25f, -2.15f, 0.0f);
	glRotatef(90, 0, 0, 1);
	glBindTexture(GL_TEXTURE_2D, textures[3]);
	draw_model(&model2);
	glPopMatrix();

	glBindTexture(GL_TEXTURE_2D, 0);
	/*glPushMatrix();
	glTranslatef(0, 0, 0);
	glBegin(GL_LINES);

	glColor3f(1, 0, 0);
	glVertex3f(10, 10, 0);
	glVertex3f(11, 10, 0);

	glColor3f(0, 1, 0);
	glVertex3f(10, 10, 0);
	glVertex3f(10, 11, 0);

	glColor3f(0, 0, 1);
	glVertex3f(10, 10, 0);
	glVertex3f(10, 10, 1);
	glPopMatrix();

	glEnd();*/

	glPushMatrix();
	draw_teapots();
	glPopMatrix();

	glFlush();
	
}

bool isCollision() {
	if(camera.position.x >= 10.0) {
		return true;
	}
	else
		return false;
}

bool changeFogColor(struct Camera* camera1) {
	if (camera1->position.x >= 10.0) {
		return true;
	}
	else
		return false;
}

bool collision(double distance) {
	bool is_collision = false;
	double angle_fb = degree_to_radian(camera.pose.z);
	double angle_l = degree_to_radian(camera.pose.z + 90.0);
	double angle_r = degree_to_radian(camera.pose.z - 90.0);
	//a h�zban van  ; 
	if (camera.position.x + cos(angle_fb) * distance > -7.12 && camera.position.x + cos(angle_fb) * distance < 7.12  && mforw() && camera.position.y + sin(angle_fb) * distance >= -28.7 && camera.position.y + sin(angle_fb) * distance <= 0) {
		//forward collision
		if (camera.position.x + cos(angle_fb) * distance> -6.3 && camera.position.x + cos(angle_fb) * distance< 6.3 && mforw() && camera.position.y + sin(angle_fb) * distance >= -5.3 && camera.position.y + sin(angle_fb) * distance <= -0.8) {
			is_collision = false;
		}
		else if(camera.position.x + cos(angle_fb) * distance> -1.68 && camera.position.x + cos(angle_fb) * distance< 1.68 && mforw() && camera.position.y + sin(angle_fb) * distance >= -1 && camera.position.y + sin(angle_fb) * distance <= 0) {
			is_collision = false;
		}
		/*else if (camera.position.x + cos(angle_fb) * distance> -7.1 && camera.position.x + cos(angle_fb) * distance< 7.1 && mforw() && camera.position.y + sin(angle_fb) * distance >= -28.6 && camera.position.y + sin(angle_fb) * distance <= -5.2 && ajto) {
			is_collision = false;
		}*/
		else
			is_collision = true;
	}
	if (camera.position.x - cos(angle_fb) * distance> -7,12 && camera.position.x - cos(angle_fb) * distance< 7,12 && mbackw() && camera.position.y - sin(angle_fb) * distance >= -28.7 && camera.position.y - sin(angle_fb) * distance <= 0) {
		//backward
		if (camera.position.x - cos(angle_fb) * distance> -6.3 && camera.position.x - cos(angle_fb) * distance< 6.3 && mbackw() && camera.position.y - sin(angle_fb) * distance >= -5.3 && camera.position.y - sin(angle_fb) * distance <= -0.8) {
			is_collision = false;
		}
		else if (camera.position.x - cos(angle_fb) * distance> -1.68 && camera.position.x - cos(angle_fb) * distance< 1.68 && mbackw() && camera.position.y - sin(angle_fb) * distance >= -1 && camera.position.y - sin(angle_fb) * distance <= 0) {
			is_collision = false;
		}
		else
			is_collision = true;
	}
	if (camera.position.x + cos(angle_l) * distance > -7.12 && camera.position.x + cos(angle_l) * distance < 7.12  && mleft() && camera.position.y + sin(angle_l) * distance >= -28.7 && camera.position.y + sin(angle_l) * distance <= 0) {
		//left
		if (camera.position.x + cos(angle_l) * distance > -6.3 && camera.position.x + cos(angle_l) * distance < 6.3 && camera.position.y + sin(angle_l) * distance >= -5.3 && camera.position.y + sin(angle_l) * distance <= -0.8) {
			is_collision = false;
		}
		else if (camera.position.x + cos(angle_l) * distance > -1.68 && camera.position.x + cos(angle_l) * distance < 1.68 && camera.position.y + sin(angle_l) * distance >= -1 && camera.position.y + sin(angle_l) * distance <= 0) {
			is_collision = false;
		}
		else
			is_collision = true;
	}
	if (camera.position.x + cos(angle_r) * distance > -7.12 && camera.position.x + cos(angle_r) * distance < 7.12  && mright() && camera.position.y + sin(angle_r) * distance >= -28.7 && camera.position.y + sin(angle_r) * distance <= 0) {
		//right
		if (camera.position.x + cos(angle_r) * distance > -6.3 && camera.position.x + cos(angle_r) * distance < 6.3 && mright() && camera.position.y + sin(angle_r) * distance >= -5.3 && camera.position.y + sin(angle_r) * distance <= -0.8) {
			is_collision = false;
		}
		else if (camera.position.x + cos(angle_r) * distance > -1.68 && camera.position.x + cos(angle_r) * distance < 1.68 && mright() && camera.position.y + sin(angle_r) * distance >= -1 && camera.position.y + sin(angle_r) * distance <= 0) {
			is_collision = false;
		}
		else
			is_collision = true;
	}

	return is_collision;

}

void update_camera_position(struct Camera* camera1, double elapsed_time)
{
    double distance;

    distance = elapsed_time * CAMERA_SPEED;
	if (collision(distance) == false) {
		if (mforw() == TRUE) {
			move_camera_forward(camera1, distance);
		}

		if (mbackw() == TRUE) {
			move_camera_backward(camera1, distance);
		}

		if (mleft() == TRUE) {
			step_camera_left(camera1, distance);
		}

		if (mright() == TRUE) {
			step_camera_right(camera1, distance);
		}
	}
	}

double calc_elapsed_time()
{
    int current_time;
    double elapsed_time;
    
    current_time = glutGet(GLUT_ELAPSED_TIME);
    elapsed_time = (double)(current_time - time) / 1000.0;
    time = current_time;

    return elapsed_time;
}

void display()
{
    double elapsed_time;

	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	
    elapsed_time = calc_elapsed_time();
    update_camera_position(&camera, elapsed_time);
	set_view_point(&camera);
	
	lightning_init();
	glDisable(GL_COLOR_MATERIAL);
	set_lightings();
    draw_origin();

	glutSwapBuffers();
}

void reshape(GLsizei width, GLsizei height)
{
    int x, y, w, h;
    double ratio;

    ratio = (double)width / height;
    if (ratio > VIEWPORT_RATIO) {
        w = (int)((double)height * VIEWPORT_RATIO);
        h = height;
        x = (width - w) / 2;
        y = 0;
    }
    else {
        w = width;
        h = (int)((double)width / VIEWPORT_RATIO);
        x = 0;
        y = (height - h) / 2;
    }

    glViewport (x, y, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(50.0, (GLdouble)width / (GLdouble)height, 0.01, 10000.0);
}

void mouse_handler(int button, int state, int x, int y)
{
	mouse_x = x;
	mouse_y = y;
}

void motion_handler(int x, int y)
{
	double horizontal, vertical;

	horizontal = mouse_x - x;
	vertical = mouse_y - y;

	if (drawMenu) {
		rotate_camera(&camera, 0, 0);
	}
	else {
		rotate_camera(&camera, horizontal, vertical);
		mouse_x = x;
		mouse_y = y;
	}
	

    glutPostRedisplay();
}

void key_handler(unsigned char key, int x, int y)
{
	if (drawMenu==FALSE) {
		switch (key) {
		case 'w':
			mforward = TRUE;
			break;
		case 's':
			mbackward = TRUE;
			break;
		case 'a':
			sleft = TRUE;
			break;
		case 'd':
			sright = TRUE;
			break;
		}
	}
		switch(key){
		case 27:
			drawMenu = FALSE;
			break;
		case 't':
			light++;
			break;
		case 'r':
			light--;
			break;
		case 'f':
			c++;
			break;
		case 'g':
			if (c < 0) {
				c -= 0;
			}
			else {
				c--;
			}
			break;
		case 'v':
			glEnable(GL_FOG);
			Fog();
			break;
		case 'b':
			glDisable(GL_FOG);
			break;
		case 'e':
			ajto = !ajto;
			break;
		case '-':
			if (lr > -1.0) {
				lr = lr - 0.1;
				lg = lg - 0.1;
				lb = lb - 0.1;
			}
			break;
		case '+':
			if (lr < 3) {
				lr = lr + 0.1;
				lg = lg + 0.1;
				lb = lb + 0.1;
			}
			break;
		case 'p':

			printf("\nx: %lf", camera.position.x);
			printf("\ny: %lf", camera.position.y);
			printf("\nz: %lf", camera.position.z);
			break;
		}

	glutPostRedisplay();
}

void special_key_handler(int key, int x, int y)
{
	switch (key) {
	case GLUT_KEY_F1:
		drawMenu = TRUE;
		break;
	}
}

void key_up_handler(unsigned char key, int x, int y)
{
	switch (key) {
	case 'w':
        mforward = FALSE;
		break;
	case 's':
        mbackward = FALSE;
		break;
	case 'a':
        sleft = FALSE;
		break;
	case 'd':
        sright = FALSE;
		break;
	}

	glutPostRedisplay();
}

void idle()
{
    glutPostRedisplay();
}

void initialize()
{
    glShadeModel(GL_SMOOTH);

    glEnable(GL_NORMALIZE);
    glEnable(GL_AUTO_NORMAL);

    glClearColor(0.0, 0.0, 0.0, 0.0);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

    glEnable(GL_DEPTH_TEST);

	glClearDepth(1.0);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	char texture_filenames[][127] = {
		"C:/Users/szilv/Downloads/Graphics/camera/camera/texture/menujavitott.jpg",
		"C:/Users/szilv/Downloads/Graphics/camera/camera/texture/grassTileable.jpg",
		"C:/Users/szilv/Downloads/Graphics/camera/camera/texture/water_texture.jpg",
		"C:/Users/szilv/Downloads/Graphics/camera/camera/texture/BrickRound0105_5_S.jpg",
		"C:/Users/szilv/Downloads/Graphics/camera/camera/texture/sky.jpg",
		"C:/Users/szilv/Downloads/Graphics/camera/camera/texture/house_modify.png",
		"C:/Users/szilv/Downloads/Graphics/camera/camera/texture/door.png",
		"C:/Users/szilv/Downloads/Graphics/camera/camera/texture/bark_0021.jpg",
		"C:/Users/szilv/Downloads/Graphics/camera/camera/texture/leaves_texture4980.jpg",
		"C:/Users/szilv/Downloads/Graphics/camera/camera/texture/woodTexture.jpg"
	};

	int i;

	for (i = 0; i < 10; i++) {
		textures[i] = LoadTextureFromFile(texture_filenames[i]);
	}

	glEnable(GL_TEXTURE_2D);
}

/**
 * Main function
 */
int main(int argc, char* argv[])
{
	load_model("C:/Users/szilv/Downloads/Graphics/camera/camera/object/house1.obj", &model);
	print_bounding_box(&model);
	load_model("C:/Users/szilv/Downloads/Graphics/camera/camera/object/branches.obj", &model1);
	print_bounding_box(&model1);
	load_model("C:/Users/szilv/Downloads/Graphics/camera/camera/object/untitled.obj", &model2);
	print_bounding_box(&model2);
	load_model("C:/Users/szilv/Downloads/Graphics/camera/camera/object/leaves.obj", &model3);
	print_bounding_box(&model3);
	load_model("C:/Users/szilv/Downloads/Graphics/camera/camera/object/table.obj", &model4);
	print_bounding_box(&model4);
    glutInit(&argc, argv);

	glutInitWindowSize(640, 480);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
	int window = glutCreateWindow("Vid�k");
	glutSetWindow(window);

    initialize();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(key_handler);
    glutKeyboardUpFunc(key_up_handler);
	glutSpecialFunc(special_key_handler);
    glutMouseFunc(mouse_handler);
    glutMotionFunc(motion_handler);
    glutIdleFunc(idle);

    init_camera(&camera);

    mforward = FALSE;
    mbackward = FALSE;
    sleft = FALSE;
    sright = FALSE;

    glutMainLoop();

	return 0;
}