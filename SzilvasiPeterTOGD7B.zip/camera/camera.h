#ifndef CAMERA_H
#define CAMERA_H
#include <stdio.h>
#include "model.h"

class Camera
{
public:	Vertex position;
public:	Vertex pose;
};

/**
* Initialize the camera position and direction.
*/
void init_camera(Camera* camera);

/**
* Transform the models into the view point of the camera.
*/
void set_view_point(Camera* camera);

/**
* Rotate the camera horizontally and vertically.
*/
void rotate_camera(Camera* camera, double horizontal, double vertical);

/**
* Move the camera forward.
*/
void move_camera_forward(Camera* camera, double distance);

/**
* Move the camera backward.
*/
void move_camera_backward(Camera* camera, double distance);

/**
* Step the camera left.
*/
void step_camera_left(Camera* camera, double distance);

/**
* Step the camera right.
*/
void step_camera_right(Camera* camera, double distance);

double degree_to_radian(double degree);

#endif // CAMERA_H

